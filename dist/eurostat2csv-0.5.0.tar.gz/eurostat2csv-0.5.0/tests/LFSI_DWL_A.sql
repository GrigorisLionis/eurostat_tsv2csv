CREATE DATABASE IF NOT EXISTS Eurostat;
USE Eurostat;
DROP TABLE IF EXISTS LFSI_DWL_A;
CREATE TABLE LFSI_DWL_A (freq VARCHAR(6),sex VARCHAR(6),geo VARCHAR(14),obs_time VARCHAR(9),value FLOAT,flags VARCHAR(6) );
LOAD DATA INFILE '/home/user/Επιφάνεια εργασίας/eurostat_sql/git_ver/eurostat_tsv2csv/tests/LFSI_DWL_A.csv'  INTO TABLE LFSI_DWL_A  FIELDS TERMINATED BY ',' IGNORE 1 LINES;
